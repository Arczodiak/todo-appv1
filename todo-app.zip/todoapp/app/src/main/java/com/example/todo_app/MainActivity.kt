package com.example.todo_app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.util.Log
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@androidx.media3.common.util.UnstableApi
class MainActivity : AppCompatActivity() {


    private lateinit var apiService: ApiService
    private var token: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:3000/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        apiService = retrofit.create(ApiService::class.java)

        // UI references
        val usernameField: EditText = findViewById(R.id.username)
        val passwordField: EditText = findViewById(R.id.password)
        val taskTitleField: EditText = findViewById(R.id.taskTitle)
        val taskDescriptionField: EditText = findViewById(R.id.taskDescription)
        val taskList: ListView = findViewById(R.id.taskList)

        val registerBtn: Button = findViewById(R.id.registerBtn)
        val loginBtn: Button = findViewById(R.id.loginBtn)
        val addTaskBtn: Button = findViewById(R.id.addTaskBtn)

        // Register
        registerBtn.setOnClickListener {
            val username = usernameField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                val userRequest = UserRequest(username, password)
                apiService.register(userRequest).enqueue(object : Callback<ApiResponse> {
                    override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                        if (response.isSuccessful) {
                            val apiResponse = response.body()
                            Toast.makeText(
                                this@MainActivity,
                                apiResponse?.message ?: "Registration success",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                "User already exists or error",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                        Log.e("Retrofit", "Error: ", t)
                        Toast.makeText(this@MainActivity, "Registration failed", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }

        // Login
        loginBtn.setOnClickListener {
            val username = usernameField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                val userRequest = UserRequest(username, password)
                apiService.login(userRequest).enqueue(object : Callback<LoginResponse> {
                    override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                        if (response.isSuccessful) {
                            val loginResponse = response.body()
                            if (loginResponse != null) {
                                token = loginResponse.token
                                Toast.makeText(this@MainActivity, "Login successful!", Toast.LENGTH_SHORT).show()
                                loadTasks(taskList)
                            }
                        } else {
                            Toast.makeText(this@MainActivity, "Invalid credentials", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                        Toast.makeText(this@MainActivity, "Login failed", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }

        // Add Task
        addTaskBtn.setOnClickListener {
            if (token == null) {
                Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val title = taskTitleField.text.toString().trim()
            val description = taskDescriptionField.text.toString().trim()
            if (title.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Title or Description is empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val taskRequest = TaskRequest(title, description, System.currentTimeMillis().toString())
            apiService.addTask("Bearer $token", taskRequest).enqueue(object : Callback<ApiResponse> {
                override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MainActivity, "Task added!", Toast.LENGTH_SHORT).show()
                        loadTasks(taskList)
                    } else {
                        Toast.makeText(this@MainActivity, "Error adding task", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Failed to add task", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    // Load tasks
    private fun loadTasks(taskList: ListView) {
        if (token == null) return
        apiService.getTasks("Bearer $token").enqueue(object : Callback<List<Task>> {
            override fun onResponse(call: Call<List<Task>>, response: Response<List<Task>>) {
                if (response.isSuccessful) {
                    val tasks = response.body().orEmpty()
                    val taskTitles = tasks.map { "${it.title} - ${it.description}" }
                    val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, taskTitles)
                    taskList.adapter = adapter
                } else {
                    Toast.makeText(this@MainActivity, "Failed to load tasks", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<List<Task>>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Failed to load tasks", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Retrofit interface + data classes
    interface ApiService {
        @POST("register")
        fun register(@Body user: UserRequest): Call<ApiResponse>

        @POST("login")
        fun login(@Body user: UserRequest): Call<LoginResponse>

        @GET("tasks")
        fun getTasks(@Header("Authorization") authHeader: String): Call<List<Task>>

        @POST("tasks")
        fun addTask(@Header("Authorization") authHeader: String, @Body task: TaskRequest): Call<ApiResponse>
    }

    data class UserRequest(val username: String, val password: String)
    data class LoginResponse(val token: String)
    data class ApiResponse(val message: String)
    data class Task(val id: Int, val title: String, val description: String, val dueDate: String)
    data class TaskRequest(val title: String, val description: String, val dueDate: String)
}
